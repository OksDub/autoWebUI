package com.example.homework5;

public class Employee {
    public String name;
    public String dolg;
    private String email;
    private String tel;
    private int zp;
    public int old;
    public Employee(String name, String dolg, String email, String tel, int zp, int old) {
        this.name = name;
        this.dolg = dolg;
        this.email = email;
        this.tel = tel;
        this.zp = zp;
        this.old = old;

    }

    void printInfo() {
        System.out.println(String.format("Сотрудник %s работает на должности %s.", name, dolg));
        System.out.println("Личная информация");
        System.out.println(String.format("Почта: %s", email));
        System.out.println(String.format("Телефон: %s", tel));
        System.out.println(String.format("Возраст: %s", old));
        System.out.println(String.format("Оклад: %s", zp));
        System.out.println();
    }

    public String getName() {
        return name;
    }

    public String getDolg() {
        return dolg;
    }

    public String getEmail() {
        return email;
    }

    public String getTel() {
        return tel;
    }

    public int getZp() {
        return zp;
    }

    public int getOld(Employee employee) {
        return old;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDolg(String dolg) {
        this.dolg = dolg;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public void setZp(int zp) {
        this.zp = zp;
    }

    public void setOld(int old) {
        this.old = old;
    }
}
