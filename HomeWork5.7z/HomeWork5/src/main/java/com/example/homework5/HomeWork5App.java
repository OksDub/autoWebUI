package com.example.homework5;

public class HomeWork5App {
    public static void main(String[] args) {
        Employee worker1 = new Employee("Андреев Андрей Андреевич", "инженер", "andreev@mail.ru", "88888888880", 30000, 42);
        Employee worker2 = new Employee("Ильин Илья Ильич", "менеджер", "andreev@mail.ru", "+78888888881", 20000, 40);
        Employee worker3 = new Employee("Дмитриев Дмитрий Дмитриевич", "механик", "dmitreev@mail.ru", "+78888888830", 40000, 39);
        Employee worker4 = new Employee("Иванов Иван Иванович", "инженер", "andreev@mail.ru", "+78888888840", 50000, 50);
        Employee worker5 = new Employee("Сергеев Сергей Сергеевич", "тестировщик", "andreev@mail.ru", "+78888888889", 100000, 35);

        worker1.printInfo();
        worker2.printInfo();
        worker3.printInfo();
        worker4.printInfo();
        worker5.printInfo();

        Employee[] workerArray = new Employee[5];
        workerArray[0] = new Employee("Андреев Андрей Андреевич", "инженер2", "andreev@mail.ru", "88888888880", 30000, 42);
        workerArray[1] = new Employee("Ильин Илья Ильич", "менеджер2", "andreev@mail.ru", "+78888888881", 20000, 40);
        workerArray[2] = new Employee("Дмитриев Дмитрий Дмитриевич", "механик2", "dmitreev@mail.ru", "+78888888830", 40000, 39);
        workerArray[3] = new Employee("Иванов Иван Иванович", "инженер2", "andreev@mail.ru", "+78888888840", 50000, 50);
        workerArray[4] = new Employee("Сергеев Сергей Сергеевич", "тестировщик2", "andreev@mail.ru", "+78888888889", 100000, 35);

        for (int i = 0; i < 5; i++) {
            if (workerArray[i].getOld(workerArray[i]) <= 40) {
                continue;
            }
            workerArray[i].printInfo();

        }


    }
}
