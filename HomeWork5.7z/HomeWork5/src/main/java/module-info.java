module com.example.homework5 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.homework5 to javafx.fxml;
    exports com.example.homework5;
}