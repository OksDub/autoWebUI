package com.example.homework7;

public class Main {
    public static void main(String[] args) {
        Plate plate = new Plate(27);

        Cat[] catsArr = new Cat[4];
        catsArr[0] = new Cat("Мурзик", 3);
        catsArr[1] = new Cat("Барсик", 6);
        catsArr[2] = new Cat("Пушок", 4);
        catsArr[3] = new Cat("Снежок", 7);


        System.out.println(plate);
        for (int i = 0; i < 4; i++) {
            catsArr[i].printCat();
        }

        System.out.println();

        for (int i = 0; i < 4; i++) {
            catsArr[i].eat(plate);
            catsArr[i].printCat();
        }
        System.out.println(plate);

//        while () {
//          Коты едят
//          коты спят
//         тарелка наполняется
//        }




    }



}