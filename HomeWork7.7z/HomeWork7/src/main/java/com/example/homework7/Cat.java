package com.example.homework7;

public class Cat {
    private final String name;
    private final int appetite;
    private boolean satiety;

    public Cat(String name, int appetite) {
        this.name = name;
        this.appetite = appetite;
        this.satiety = false;
    }

    //public void makeHungry()
    public void printCat() {
        System.out.printf(name+" c аппетитом %s поел "+satiety+"%n", appetite);
    }

    public void eat(Plate plate) {
        satiety = plate.decreaseFood(appetite);

    }
    @Override
    public String toString() {
        return "Cat{" +
                "name='" + name + '\'' +
                ", appetite=" + appetite +
                ", satiety=" + satiety +
                '}';
    }
}
