module com.example.gamehomework4 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.gamehomework4 to javafx.fxml;
    exports com.example.gamehomework4;
}