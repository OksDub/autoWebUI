package com.example.gamehomework4;

import java.util.Random;
import java.util.Scanner;

public class HomeWork4App {


    public static final String HEADER_SUMBOL = "\\";
    public static final String SPACE = " ";
    public static final int MAX_SIZE_MAP = 10;
    public static int SIZE;
    public static int DOTS_TO_WIN;
    public static final char DOT_EMPTY = '•';
    public static final char DOT_X = 'X';
    public static final char DOT_O = 'O';
    public static char[][] map;
    public static Scanner sc = new Scanner(System.in);
    public static Random rand = new Random();


    public static void main(String[] args) {
        do {
            System.out.println("Начнем игру!");
            init();
            printMap();
            playGame();
        } while (startNewGame());
    }

    private static void playGame() {
        while (true) {
            humanTurn();
            printMap();
            if (checkEnd(DOT_X)) {
                break;
            }
            aiTurn();
            printMap();
            if (checkEnd(DOT_O)) {
                break;
            }

        }
        System.out.println("Игра закончена");
    }

    public static void init() {
        SIZE = getSizeMap();
        DOTS_TO_WIN = winSize();
        initMap();
    }

    public static void initMap() {

        map = new char[SIZE][SIZE];
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                map[i][j] = DOT_EMPTY;
            }
        }
    }

    public static int getSizeMap() {
        System.out.println("Введите размерность поля:");
        int sizeMap = sc.nextInt();

        return sizeMap;
    }

    public static int winSize() {
        return switch (SIZE) {
            case 3, 4, 5 -> 3;
            case 6, 7, 8, 9 -> 4;
            default -> 5;
        };

    }

    public static void printMap() {
        printHeaderMap();
        printBodyMap();
        System.out.println();
    }

    private static void printBodyMap() {
        for (int i = 0; i < SIZE; i++) {
            System.out.print((i + 1) + SPACE);
            for (int j = 0; j < SIZE; j++) {
                System.out.print(map[i][j] + SPACE);
            }
            System.out.println();
        }
    }

    private static void printHeaderMap() {
        System.out.print(HEADER_SUMBOL + SPACE);
        for (int i = 0; i < SIZE; i++) {
            System.out.print((i + 1) + SPACE);
        }
        System.out.println();
    }

    public static boolean checkEnd(char symb) {
        if (checkWin(symb)) {
            if (symb == DOT_X) {
                System.out.println("Победил человек");

            } else {
                System.out.println("Победил Искуственный Интеллект");
            }
            return true;
        }

        if (isMapFull()) {
            System.out.println("Ничья");
            return true;
        }
        return false;
    }


    public static boolean checkWin(char symb) {
        for (int i = 0; i < SIZE - DOTS_TO_WIN + 1; i++) {
            for (int j = 0; j < SIZE - DOTS_TO_WIN +1; j++) {

                if (checkDiag(symb, i) || checkLine(symb, i, j)) return true;
            }
        }

        return false;
    }

    public static boolean isMapFull() {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                if (map[i][j] == DOT_EMPTY) return false;
            }
        }
        return true;
    }

    public static void aiTurn() {
        int x, y;
        do {
            x = rand.nextInt(SIZE);
            y = rand.nextInt(SIZE);
        } while (!isCellValid(x, y));
        System.out.println("Компьютер походил в точку " + (x + 1) + " " + (y +
                1));
        map[x][y] = DOT_O;
    }

    public static void humanTurn() {
        int rowX;
        int columnY;
        while (true) {
            System.out.println("Введите координаты в формате: Строка Столбец");
            rowX = sc.nextInt() - 1;
            columnY = sc.nextInt() - 1;
            if (isCellValid(rowX, columnY)) {
                break;
            } else {
                System.out.println("Клетка занята или координаты неверны. Попробуйте еще раз.");
            }
        }
        // while(isCellValid(x, y) == false)
        map[rowX][columnY] = DOT_X;
    }

    public static boolean isCellValid(int x, int y) {
        if (x < 0 || x >= SIZE || y < 0 || y >= SIZE) return false;
        if (map[x][y] == DOT_EMPTY) return true;
        return false;
    }

    private static boolean startNewGame() {
        System.out.println("Сыграем еще раз? y\\n");
        return switch (sc.next()) {
            case "y", "у", "+", "да" -> true;
            default -> false;
        };
    }

    private static boolean checkDiag(char symb, int x) {
        boolean mainDi = true;
        boolean sideDi = true;
        for (int i = 0; i < DOTS_TO_WIN; i++) {
            mainDi &= (map[i][i] == symb);
            sideDi &= (map[DOTS_TO_WIN - i - 1][i] == symb);

        }

        return (mainDi || sideDi);
    }

    private static boolean checkLine(char symb, int x, int y) {
        boolean column = true;
        boolean line = true;
        for (int i = x; i < x+DOTS_TO_WIN; i++) {
            for (int j = y; j < y+DOTS_TO_WIN; j++) {
               line &= (map[i][j] == symb);
               column &= (map[j][i] == symb);

            }

        }


        return (column || line);

    }


}

